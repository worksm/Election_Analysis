# Create a Python list to store your grocery list

# Print the grocery list

# Change "Peanut Butter" to "Almond Butter" and print out the updated list

# Remove "Jelly" from grocery list and print out the updated list

# Add "Coffee" to grocery list and print the updated list
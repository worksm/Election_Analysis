# Grocery Store List

## Instructions

* Create a Python list to store the following items as a list of strings. You need to buy:
    * Milk
    * Bread
    * Eggs
    * Peanut Butter
    * Jelly

* Print out the list

* Wait! Your cousin is visiting next week, and they’re only allergic to peanuts! Change “peanut butter” in the list to “almond butter”.

* You just remembered that you have homemade jam that your neighbor made for you. Remove “jelly” from the list.
    
* You just used up the last of your coffee. Add “coffee” to your grocery list.
    
* Print out the updated list.

---

© 2021 Trilogy Education Services, LLC, a 2U, Inc. brand.  Confidential and Proprietary.  All Rights Reserved.